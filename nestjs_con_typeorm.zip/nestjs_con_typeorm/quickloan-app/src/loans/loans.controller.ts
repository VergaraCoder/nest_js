import {Post, Body, Controller, Get, Param } from '@nestjs/common';

@Controller('loans')
export class LoansController {
    @Post()
    createLoan(@Body() createLoadDto:any){
        console.log(createLoadDto);
        
        return  createLoadDto;
    }

    @Get(":id")
    getLoans(@Param('id') idLoan:string){
        return `El dato tiene el id ` +(+idLoan+1);
    }
}
