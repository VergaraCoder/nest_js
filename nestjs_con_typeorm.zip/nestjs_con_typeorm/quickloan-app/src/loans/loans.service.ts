import { Injectable } from '@nestjs/common';

@Injectable()
export class LoansService {
    calculateLoanRisk(mountLoan:any){
        if(mountLoan.creditScore > 700){
            return 'Low Risk';
        }else{
            return 'high risk';
        }
    }
}
