import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { LoansController } from './loans/loans.controller';
import { LoansService } from './loans/loans.service';
import { LoansModule } from './loans/loans.module';

@Module({
  imports: [UsersModule, LoansModule],
  controllers: [AppController, LoansController],
  providers: [AppService, LoansService],
})
export class AppModule {}
